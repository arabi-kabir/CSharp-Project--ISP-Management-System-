﻿namespace Presentation_Layer
{
    partial class FNewEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FNewEntry));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.DropdownArea = new Bunifu.Framework.UI.BunifuDropdown();
            this.DatepickerStartDate = new Bunifu.Framework.UI.BunifuDatepicker();
            this.BAddNewCustomer = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BBackHome = new Bunifu.Framework.UI.BunifuFlatButton();
            this.txtCustomerName = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtCustomerNID = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtCustomerMobile = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtCustomerEmail = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtCustomerLoaction = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtCustomerAmount = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtCustomerIPAddress = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCustomerID = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(43, 88);
            this.label1.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(43, 173);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "NID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(45, 304);
            this.label4.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 22);
            this.label4.TabIndex = 5;
            this.label4.Text = "Area";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(45, 262);
            this.label5.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "Email";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(45, 221);
            this.label6.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 22);
            this.label6.TabIndex = 3;
            this.label6.Text = "Mobile";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(45, 538);
            this.label9.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(70, 22);
            this.label9.TabIndex = 9;
            this.label9.Text = "Amount";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(45, 442);
            this.label10.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 22);
            this.label10.TabIndex = 8;
            this.label10.Text = "Package No";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(45, 393);
            this.label11.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 22);
            this.label11.TabIndex = 7;
            this.label11.Text = "Start Date";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(45, 346);
            this.label12.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(90, 22);
            this.label12.TabIndex = 6;
            this.label12.Text = "Location";
            // 
            // DropdownArea
            // 
            this.DropdownArea.BackColor = System.Drawing.Color.Transparent;
            this.DropdownArea.BorderRadius = 3;
            this.DropdownArea.DisabledColor = System.Drawing.Color.Gray;
            this.DropdownArea.ForeColor = System.Drawing.Color.White;
            this.DropdownArea.Items = new string[] {
        "Dhanmondi",
        "Mirpur",
        "Banani",
        "Mohammadpur",
        "Baridhara",
        "Basundhara"};
            this.DropdownArea.Location = new System.Drawing.Point(171, 304);
            this.DropdownArea.Name = "DropdownArea";
            this.DropdownArea.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.DropdownArea.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.DropdownArea.selectedIndex = -1;
            this.DropdownArea.Size = new System.Drawing.Size(266, 28);
            this.DropdownArea.TabIndex = 17;
            // 
            // DatepickerStartDate
            // 
            this.DatepickerStartDate.BackColor = System.Drawing.Color.SeaGreen;
            this.DatepickerStartDate.BorderRadius = 0;
            this.DatepickerStartDate.ForeColor = System.Drawing.Color.White;
            this.DatepickerStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.DatepickerStartDate.FormatCustom = null;
            this.DatepickerStartDate.Location = new System.Drawing.Point(171, 390);
            this.DatepickerStartDate.Name = "DatepickerStartDate";
            this.DatepickerStartDate.Size = new System.Drawing.Size(266, 30);
            this.DatepickerStartDate.TabIndex = 19;
            this.DatepickerStartDate.Value = new System.DateTime(2017, 12, 5, 1, 46, 41, 621);
            // 
            // BAddNewCustomer
            // 
            this.BAddNewCustomer.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.BAddNewCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.BAddNewCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BAddNewCustomer.BorderRadius = 0;
            this.BAddNewCustomer.ButtonText = "Submit";
            this.BAddNewCustomer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BAddNewCustomer.DisabledColor = System.Drawing.Color.Gray;
            this.BAddNewCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BAddNewCustomer.Iconcolor = System.Drawing.Color.Transparent;
            this.BAddNewCustomer.Iconimage = ((System.Drawing.Image)(resources.GetObject("BAddNewCustomer.Iconimage")));
            this.BAddNewCustomer.Iconimage_right = null;
            this.BAddNewCustomer.Iconimage_right_Selected = null;
            this.BAddNewCustomer.Iconimage_Selected = null;
            this.BAddNewCustomer.IconMarginLeft = 10;
            this.BAddNewCustomer.IconMarginRight = 0;
            this.BAddNewCustomer.IconRightVisible = true;
            this.BAddNewCustomer.IconRightZoom = 0D;
            this.BAddNewCustomer.IconVisible = true;
            this.BAddNewCustomer.IconZoom = 90D;
            this.BAddNewCustomer.IsTab = false;
            this.BAddNewCustomer.Location = new System.Drawing.Point(169, 587);
            this.BAddNewCustomer.Name = "BAddNewCustomer";
            this.BAddNewCustomer.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.BAddNewCustomer.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.BAddNewCustomer.OnHoverTextColor = System.Drawing.Color.White;
            this.BAddNewCustomer.selected = false;
            this.BAddNewCustomer.Size = new System.Drawing.Size(268, 49);
            this.BAddNewCustomer.TabIndex = 22;
            this.BAddNewCustomer.Text = "Submit";
            this.BAddNewCustomer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.BAddNewCustomer.Textcolor = System.Drawing.Color.White;
            this.BAddNewCustomer.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BAddNewCustomer.Click += new System.EventHandler(this.BAddNewCustomer_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(154, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(270, 32);
            this.label7.TabIndex = 23;
            this.label7.Text = "Add New Customer ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.panel1.Controls.Add(this.BBackHome);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(493, 70);
            this.panel1.TabIndex = 24;
            // 
            // BBackHome
            // 
            this.BBackHome.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.BBackHome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.BBackHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.BBackHome.BorderRadius = 0;
            this.BBackHome.ButtonText = "Back";
            this.BBackHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BBackHome.DisabledColor = System.Drawing.Color.Gray;
            this.BBackHome.Iconcolor = System.Drawing.Color.Transparent;
            this.BBackHome.Iconimage = ((System.Drawing.Image)(resources.GetObject("BBackHome.Iconimage")));
            this.BBackHome.Iconimage_right = null;
            this.BBackHome.Iconimage_right_Selected = null;
            this.BBackHome.Iconimage_Selected = null;
            this.BBackHome.IconMarginLeft = 0;
            this.BBackHome.IconMarginRight = 0;
            this.BBackHome.IconRightVisible = true;
            this.BBackHome.IconRightZoom = 0D;
            this.BBackHome.IconVisible = true;
            this.BBackHome.IconZoom = 90D;
            this.BBackHome.IsTab = false;
            this.BBackHome.Location = new System.Drawing.Point(10, 9);
            this.BBackHome.Name = "BBackHome";
            this.BBackHome.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(56)))), ((int)(((byte)(70)))));
            this.BBackHome.OnHovercolor = System.Drawing.Color.Teal;
            this.BBackHome.OnHoverTextColor = System.Drawing.Color.White;
            this.BBackHome.selected = false;
            this.BBackHome.Size = new System.Drawing.Size(102, 55);
            this.BBackHome.TabIndex = 33;
            this.BBackHome.Text = "Back";
            this.BBackHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BBackHome.Textcolor = System.Drawing.Color.White;
            this.BBackHome.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BBackHome.Click += new System.EventHandler(this.BBackHome_Click);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.BorderColorFocused = System.Drawing.Color.DarkCyan;
            this.txtCustomerName.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerName.BorderColorMouseHover = System.Drawing.Color.DarkCyan;
            this.txtCustomerName.BorderThickness = 3;
            this.txtCustomerName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCustomerName.ForeColor = System.Drawing.Color.White;
            this.txtCustomerName.isPassword = false;
            this.txtCustomerName.Location = new System.Drawing.Point(169, 83);
            this.txtCustomerName.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(268, 35);
            this.txtCustomerName.TabIndex = 25;
            this.txtCustomerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtCustomerNID
            // 
            this.txtCustomerNID.BorderColorFocused = System.Drawing.Color.DarkCyan;
            this.txtCustomerNID.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerNID.BorderColorMouseHover = System.Drawing.Color.DarkCyan;
            this.txtCustomerNID.BorderThickness = 3;
            this.txtCustomerNID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerNID.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCustomerNID.ForeColor = System.Drawing.Color.White;
            this.txtCustomerNID.isPassword = false;
            this.txtCustomerNID.Location = new System.Drawing.Point(169, 169);
            this.txtCustomerNID.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerNID.Name = "txtCustomerNID";
            this.txtCustomerNID.Size = new System.Drawing.Size(268, 35);
            this.txtCustomerNID.TabIndex = 27;
            this.txtCustomerNID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtCustomerMobile
            // 
            this.txtCustomerMobile.BorderColorFocused = System.Drawing.Color.DarkCyan;
            this.txtCustomerMobile.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerMobile.BorderColorMouseHover = System.Drawing.Color.DarkCyan;
            this.txtCustomerMobile.BorderThickness = 3;
            this.txtCustomerMobile.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerMobile.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCustomerMobile.ForeColor = System.Drawing.Color.White;
            this.txtCustomerMobile.isPassword = false;
            this.txtCustomerMobile.Location = new System.Drawing.Point(169, 212);
            this.txtCustomerMobile.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerMobile.Name = "txtCustomerMobile";
            this.txtCustomerMobile.Size = new System.Drawing.Size(268, 35);
            this.txtCustomerMobile.TabIndex = 28;
            this.txtCustomerMobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtCustomerEmail
            // 
            this.txtCustomerEmail.BorderColorFocused = System.Drawing.Color.DarkCyan;
            this.txtCustomerEmail.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerEmail.BorderColorMouseHover = System.Drawing.Color.DarkCyan;
            this.txtCustomerEmail.BorderThickness = 3;
            this.txtCustomerEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerEmail.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCustomerEmail.ForeColor = System.Drawing.Color.White;
            this.txtCustomerEmail.isPassword = false;
            this.txtCustomerEmail.Location = new System.Drawing.Point(169, 255);
            this.txtCustomerEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerEmail.Name = "txtCustomerEmail";
            this.txtCustomerEmail.Size = new System.Drawing.Size(268, 35);
            this.txtCustomerEmail.TabIndex = 29;
            this.txtCustomerEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtCustomerLoaction
            // 
            this.txtCustomerLoaction.BorderColorFocused = System.Drawing.Color.DarkCyan;
            this.txtCustomerLoaction.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerLoaction.BorderColorMouseHover = System.Drawing.Color.DarkCyan;
            this.txtCustomerLoaction.BorderThickness = 3;
            this.txtCustomerLoaction.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerLoaction.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCustomerLoaction.ForeColor = System.Drawing.Color.White;
            this.txtCustomerLoaction.isPassword = false;
            this.txtCustomerLoaction.Location = new System.Drawing.Point(169, 342);
            this.txtCustomerLoaction.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerLoaction.Name = "txtCustomerLoaction";
            this.txtCustomerLoaction.Size = new System.Drawing.Size(268, 35);
            this.txtCustomerLoaction.TabIndex = 30;
            this.txtCustomerLoaction.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtCustomerAmount
            // 
            this.txtCustomerAmount.BorderColorFocused = System.Drawing.Color.DarkCyan;
            this.txtCustomerAmount.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerAmount.BorderColorMouseHover = System.Drawing.Color.DarkCyan;
            this.txtCustomerAmount.BorderThickness = 3;
            this.txtCustomerAmount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerAmount.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCustomerAmount.ForeColor = System.Drawing.Color.White;
            this.txtCustomerAmount.isPassword = false;
            this.txtCustomerAmount.Location = new System.Drawing.Point(169, 534);
            this.txtCustomerAmount.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerAmount.Name = "txtCustomerAmount";
            this.txtCustomerAmount.Size = new System.Drawing.Size(268, 35);
            this.txtCustomerAmount.TabIndex = 32;
            this.txtCustomerAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtCustomerIPAddress
            // 
            this.txtCustomerIPAddress.BorderColorFocused = System.Drawing.Color.DarkCyan;
            this.txtCustomerIPAddress.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerIPAddress.BorderColorMouseHover = System.Drawing.Color.DarkCyan;
            this.txtCustomerIPAddress.BorderThickness = 3;
            this.txtCustomerIPAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerIPAddress.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCustomerIPAddress.ForeColor = System.Drawing.Color.White;
            this.txtCustomerIPAddress.isPassword = false;
            this.txtCustomerIPAddress.Location = new System.Drawing.Point(170, 484);
            this.txtCustomerIPAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerIPAddress.Name = "txtCustomerIPAddress";
            this.txtCustomerIPAddress.Size = new System.Drawing.Size(268, 35);
            this.txtCustomerIPAddress.TabIndex = 34;
            this.txtCustomerIPAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(46, 489);
            this.label8.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 22);
            this.label8.TabIndex = 33;
            this.label8.Text = "IP Address";
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.BorderColorFocused = System.Drawing.Color.DarkCyan;
            this.txtCustomerID.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerID.BorderColorMouseHover = System.Drawing.Color.DarkCyan;
            this.txtCustomerID.BorderThickness = 3;
            this.txtCustomerID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerID.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtCustomerID.ForeColor = System.Drawing.Color.White;
            this.txtCustomerID.isPassword = false;
            this.txtCustomerID.Location = new System.Drawing.Point(169, 126);
            this.txtCustomerID.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.Size = new System.Drawing.Size(268, 35);
            this.txtCustomerID.TabIndex = 26;
            this.txtCustomerID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(43, 131);
            this.label2.Margin = new System.Windows.Forms.Padding(3, 0, 3, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer ID";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(170, 443);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(268, 21);
            this.comboBox1.TabIndex = 35;
            // 
            // FNewEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(35)))), ((int)(((byte)(44)))));
            this.ClientSize = new System.Drawing.Size(492, 656);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.txtCustomerIPAddress);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtCustomerAmount);
            this.Controls.Add(this.txtCustomerLoaction);
            this.Controls.Add(this.txtCustomerEmail);
            this.Controls.Add(this.txtCustomerMobile);
            this.Controls.Add(this.txtCustomerNID);
            this.Controls.Add(this.txtCustomerID);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.BAddNewCustomer);
            this.Controls.Add(this.DatepickerStartDate);
            this.Controls.Add(this.DropdownArea);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FNewEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Customer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FNewEntry_FormClosing);
            this.Load += new System.EventHandler(this.FNewEntry_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private Bunifu.Framework.UI.BunifuDropdown DropdownArea;
        private Bunifu.Framework.UI.BunifuDatepicker DatepickerStartDate;
        private Bunifu.Framework.UI.BunifuFlatButton BAddNewCustomer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCustomerName;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCustomerNID;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCustomerMobile;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCustomerEmail;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCustomerLoaction;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCustomerAmount;
        private Bunifu.Framework.UI.BunifuFlatButton BBackHome;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCustomerIPAddress;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtCustomerID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}